# Changelog - Policy Management Policy

## [1.0] - 2025-01-01
- Initial publication
- Aligned with NIST 800-53 Rev 5
